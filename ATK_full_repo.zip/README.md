# ATK (Architecture Toolkit)

Data-driven Cloud Decision Logic Kit.

- Edit `/data/master/master-matrix.json` quarterly.
- Run `npm run validate && npm run build`.
- Use `/generated/*` as the exported catalog for UIs and downstream tooling.
